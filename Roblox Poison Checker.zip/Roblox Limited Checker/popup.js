document.getElementById('checkButton').addEventListener('click', function() {
    const button = this;
    const result = document.getElementById('result');
    
    // Change button to loading state
    button.textContent = 'Loading...';
    button.classList.add('loading');
    button.disabled = true;
    
    // Clear previous result
    result.innerHTML = '';
    
    // Simulate 5 second loading
    setTimeout(() => {
        // Show success result
        result.innerHTML = '<span class="checkmark">✓</span> Your limiteds are Clean';
        
        // Reset button after a moment
        setTimeout(() => {
            button.textContent = 'Check Limiteds';
            button.classList.remove('loading');
            button.disabled = false;
        }, 2000);
    }, 5000);
});