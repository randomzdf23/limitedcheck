// Send message to content script when extension icon is clicked
chrome.action.onClicked.addListener((tab) => {
    // Only send to Roblox trade pages
    if (tab.url.includes('roblox.com/trades')) {
        chrome.tabs.sendMessage(tab.id, {action: "runInstantly"}, (response) => {
            console.log('Instant scan completed');
        });
    }
});